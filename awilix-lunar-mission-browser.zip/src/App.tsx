import { useMemo, useState, type CSSProperties, type ReactNode } from 'react';
import {
  Activity,
  ArrowDownRight,
  ArrowUpRight,
  BarChart3,
  Bell,
  CalendarDays,
  Check,
  ChevronDown,
  CircleHelp,
  Clock3,
  Command,
  Compass,
  Cpu,
  Database,
  ExternalLink,
  Globe2,
  Info,
  LineChart,
  Menu,
  MessageCircle,
  Minus,
  Moon,
  Move3d,
  PanelLeftClose,
  PanelLeftOpen,
  Radio,
  Radar,
  Search,
  Send,
  Settings2,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Sun,
  X,
  Zap,
} from 'lucide-react';
import { getSite, sites, type Site } from '@/data/sites';

type View = 'overview' | 'globe' | 'sites' | 'analysis' | 'compare' | 'scenario' | 'astra';
type Scenario = {
  date: string;
  windowHours: number;
  observerHeight: number;
  antennaHeight: number;
  panelTilt: number;
  panelAzimuth: number;
};
type Sample = { label: string; sun: number; earth: number; power: number; comm: number; sunAlt: number; earthAlt: number };
type Message = { role: 'astra' | 'user'; text: string };

const DEFAULT_SCENARIO: Scenario = {
  date: '2026-11-13',
  windowHours: 48,
  observerHeight: 2,
  antennaHeight: 2,
  panelTilt: 8,
  panelAzimuth: 180,
};

const navigation: { id: View; label: string; icon: typeof Globe2 }[] = [
  { id: 'overview', label: 'Mission Overview', icon: Command },
  { id: 'globe', label: 'Lunar Globe', icon: Globe2 },
  { id: 'sites', label: 'Candidate Sites', icon: Radar },
  { id: 'analysis', label: 'Site Analysis', icon: LineChart },
  { id: 'compare', label: 'Compare Sites', icon: BarChart3 },
  { id: 'scenario', label: 'Scenario Lab', icon: SlidersHorizontal },
  { id: 'astra', label: 'Astra Assistant', icon: Sparkles },
];

const colors = ['#65d5d0', '#f0a970', '#9aaeff', '#d7de88', '#fb887a', '#cab6ff'];

const clamp = (value: number, min: number, max: number): number => Math.min(max, Math.max(min, value));

function getDayOfYear(value: string): number {
  const date = new Date(`${value}T00:00:00Z`);
  const start = new Date(Date.UTC(date.getUTCFullYear(), 0, 0));
  return Math.floor((date.getTime() - start.getTime()) / 86400000);
}

function getSamples(site: Site, scenario: Scenario): Sample[] {
  const day = getDayOfYear(scenario.date);
  const count = scenario.windowHours <= 48 ? 12 : 16;
  const sunlightSwing = Math.max(1.4, (90 + site.lat) * 0.85 + 2.6);
  const earthSwing = site.lat < -88 ? 5 : 2.8;
  const scenarioLift = scenario.observerHeight * 0.12 + scenario.antennaHeight * 0.08;
  return Array.from({ length: count }, (_, index) => {
    const progress = index / (count - 1);
    const lunarPhase = ((day + progress * (scenario.windowHours / 24)) / 29.53) * Math.PI * 2;
    const sunAlt = Math.sin(lunarPhase) * sunlightSwing + (90 + site.lat) * 0.16;
    const earthAlt = (90 + site.lat) * 0.82 + Math.sin(lunarPhase + site.lon * 0.02) * earthSwing + scenario.antennaHeight * 0.14;
    const sun = clamp(site.baseSunlight + Math.sin(lunarPhase) * (100 - site.baseSunlight) * 0.18 + scenarioLift, 0, 99);
    const earth = clamp(site.baseEarth + Math.cos(lunarPhase + 0.6) * 3.5 + scenarioLift, 0, 99);
    const incidence = clamp(Math.cos(((Math.abs(sunAlt - scenario.panelTilt) + Math.abs(scenario.panelAzimuth - 180) * 0.015) * Math.PI) / 180), 0.18, 1);
    const power = clamp((sun / 100) * incidence * 100, 0, 99);
    const comm = clamp(earth * (earthAlt > 0 ? 1 : 0.24), 0, 99);
    const hours = progress * scenario.windowHours;
    const label = hours === 0 ? 'T+00h' : `T+${Math.round(hours)}h`;
    return { label, sun, earth, power, comm, sunAlt, earthAlt };
  });
}

function getSummary(site: Site, scenario: Scenario) {
  const samples = getSamples(site, scenario);
  const average = (key: keyof Pick<Sample, 'sun' | 'earth' | 'power' | 'comm'>): number =>
    Math.round(samples.reduce((sum, sample) => sum + sample[key], 0) / samples.length);
  return {
    samples,
    sunlight: average('sun'),
    earth: average('earth'),
    power: average('power'),
    comm: average('comm'),
    peakSunAlt: Math.max(...samples.map((sample) => sample.sunAlt)),
    peakEarthAlt: Math.max(...samples.map((sample) => sample.earthAlt)),
  };
}

function formatCoordinate(value: number, positive: string, negative: string): string {
  if (value === 0) return '0°';
  return `${Math.abs(value).toFixed(value % 1 === 0 ? 0 : 1)}° ${value > 0 ? positive : negative}`;
}

function buildPath(samples: Sample[], key: keyof Pick<Sample, 'sun' | 'earth' | 'power'>, width = 720, height = 210): string {
  return samples
    .map((sample, index) => {
      const x = (index / (samples.length - 1)) * width;
      const y = height - (sample[key] / 100) * (height - 24) - 12;
      return `${index === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
    })
    .join(' ');
}

function buildArea(samples: Sample[], key: keyof Pick<Sample, 'sun' | 'earth' | 'power'>, width = 720, height = 210): string {
  return `${buildPath(samples, key, width, height)} L ${width} ${height} L 0 ${height} Z`;
}

function MetricCard({ label, value, unit, tone, detail, icon: Icon }: { label: string; value: string; unit?: string; tone: 'cyan' | 'amber' | 'blue' | 'green'; detail: string; icon: typeof Sun }) {
  return (
    <div className={`metric-card metric-${tone}`}>
      <div className="metric-top"><span>{label}</span><Icon size={15} /></div>
      <div className="metric-value">{value}<small>{unit}</small></div>
      <div className="metric-detail">{detail}</div>
    </div>
  );
}

function SectionTitle({ eyebrow, title, description, action }: { eyebrow: string; title: string; description?: string; action?: ReactNode }) {
  return (
    <div className="section-title">
      <div><span className="eyebrow">{eyebrow}</span><h2>{title}</h2>{description && <p>{description}</p>}</div>
      {action}
    </div>
  );
}

function Sparkline({ samples, dataKey, color = '#65d5d0' }: { samples: Sample[]; dataKey: keyof Pick<Sample, 'sun' | 'earth' | 'power'>; color?: string }) {
  return <svg className="sparkline" viewBox="0 0 720 210" role="img" aria-label={`${dataKey} over time`}><path d={buildArea(samples, dataKey)} fill={`${color}18`} /><path d={buildPath(samples, dataKey)} fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />{samples.map((sample, index) => <circle key={`${sample.label}-${dataKey}`} cx={(index / (samples.length - 1)) * 720} cy={210 - (sample[dataKey] / 100) * 186 - 12} r="3" fill={color} />)}</svg>;
}

function MiniBars({ value, color }: { value: number; color: string }) {
  return <div className="mini-bars" aria-label={`${value}%`}><span style={{ width: `${value}%`, background: color }} /><b>{value}%</b></div>;
}

function AstraAvatar({ compact = false }: { compact?: boolean }) {
  return <div className={`astra-avatar ${compact ? 'astra-avatar-compact' : ''}`} aria-hidden="true"><div className="astra-aura" /><div className="astra-helmet"><div className="astra-visor"><i /><i /></div><span className="astra-ear left" /><span className="astra-ear right" /></div><div className="astra-body"><span className="astra-chest">A</span><span className="astra-arm left" /><span className="astra-arm right" /></div></div>;
}

function LunarGlobe({ selectedId, onSelect, compact = false }: { selectedId: string; onSelect: (id: string) => void; compact?: boolean }) {
  const markerPositions: Record<string, { x: number; y: number }> = {
    'shackleton-rim': { x: 50, y: 18 },
    'malapert-a': { x: 43, y: 32 },
    'mons-mouton': { x: 65, y: 38 },
    nobile: { x: 77, y: 28 },
    'shackleton-ridge': { x: 54, y: 25 },
    'south-pole': { x: 50, y: 48 },
  };
  return <div className={`globe-scene ${compact ? 'globe-compact' : ''}`}><div className="star-field" /><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="moon-disc"><div className="moon-shadow" /><div className="crater crater-one" /><div className="crater crater-two" /><div className="crater crater-three" /><div className="crater crater-four" /><div className="polar-cap" /><div className="pole-ring" />{sites.map((site, index) => { const position = markerPositions[site.id]; return <button key={site.id} className={`site-marker ${selectedId === site.id ? 'selected' : ''}`} style={{ left: `${position.x}%`, top: `${position.y}%`, '--marker-color': colors[index] } as CSSProperties} onClick={() => onSelect(site.id)} title={`Open ${site.name}`}><span>{index + 1}</span><b>{site.shortName}</b></button>; })}</div><div className="scene-sun"><Sun size={compact ? 16 : 22} /><span>SUN VECTOR</span></div><div className="scene-earth"><div className="earth-disc"><span /></div><span>EARTH</span></div><div className="scene-caption"><Move3d size={14} /> drag to rotate · click a site marker</div></div>;
}

function SiteCard({ site, selected, onSelect, onOpen, index, scenario }: { site: Site; selected: boolean; onSelect: () => void; onOpen: () => void; index: number; scenario: Scenario }) {
  const summary = getSummary(site, scenario);
  return <article className={`site-card ${selected ? 'site-card-selected' : ''}`}><div className="site-card-top"><span className="site-index" style={{ color: colors[index], borderColor: `${colors[index]}55` }}>0{index + 1}</span><button className={`selection-check ${selected ? 'checked' : ''}`} onClick={onSelect} aria-label={`${selected ? 'Remove' : 'Add'} ${site.name} ${selected ? 'from' : 'to'} comparison`}>{selected && <Check size={13} />}</button></div><div className="site-card-heading"><div><h3>{site.name}</h3><p>{formatCoordinate(site.lat, 'N', 'S')} / {formatCoordinate(site.lon, 'E', 'W')}</p></div><span className="site-status"><span />{summary.sunlight > 75 ? 'FAVOURABLE' : 'WATCH'}</span></div><div className="site-card-visual"><div className="terrain-ridge" /><div className="terrain-ridge terrain-ridge-two" /><div className="terrain-sun"><Sun size={14} /></div><div className="terrain-grid" /></div><div className="site-card-stats"><div><span>Sunlight</span><strong>{summary.sunlight}%</strong></div><div><span>Earth link</span><strong>{summary.earth}%</strong></div><div><span>Power</span><strong>{summary.power}%</strong></div></div><button className="text-button" onClick={onOpen}>Open site analysis <ArrowUpRight size={14} /></button></article>;
}

function ChartPanel({ site, scenario }: { site: Site; scenario: Scenario }) {
  const summary = getSummary(site, scenario);
  return <div className="chart-panel"><div className="chart-panel-head"><div><span className="eyebrow">TIME SERIES · {scenario.windowHours}H WINDOW</span><h3>Illumination and link profile</h3></div><div className="chart-legend"><span><i className="legend-sun" />Sun visibility</span><span><i className="legend-earth" />Earth visibility</span><span><i className="legend-power" />Power opportunity</span></div></div><div className="chart-axis"><span>100%</span><span>75%</span><span>50%</span><span>25%</span><span>0%</span><div className="chart-lines"><i /><i /><i /><i /><i /></div><div className="chart-area"><Sparkline samples={summary.samples} dataKey="sun" color="#f0a970" /><Sparkline samples={summary.samples} dataKey="earth" color="#65d5d0" /><Sparkline samples={summary.samples} dataKey="power" color="#9aaeff" /></div></div><div className="chart-labels">{summary.samples.map((sample) => <span key={sample.label}>{sample.label}</span>)}</div><div className="chart-footnote"><Info size={13} /> Reference-sphere visibility estimate · 10-minute or 30-minute sampling in the original runtime model</div></div>;
}

function AstroReadout({ site, scenario }: { site: Site; scenario: Scenario }) {
  const summary = getSummary(site, scenario);
  return <div className="astro-readout"><div className="astro-readout-head"><div><span className="eyebrow">LOCAL SKY MODEL</span><h3>Polar horizon readout</h3></div><span className="live-pill"><span />LIVE MODEL</span></div><div className="horizon-display"><div className="horizon-circle"><div className="horizon-cross horizontal" /><div className="horizon-cross vertical" /><div className="horizon-arc" /><div className="sky-sun" style={{ transform: `rotate(${28 + Math.abs(summary.peakSunAlt) * 7}deg) translateY(-74px)` }}><Sun size={17} /></div><div className="sky-earth" style={{ transform: `rotate(${145 - site.lon * 0.3}deg) translateY(-58px)` }}><Globe2 size={15} /></div><span className="horizon-label horizon-n">N</span><span className="horizon-label horizon-e">E</span><span className="horizon-label horizon-s">S</span><span className="horizon-label horizon-w">W</span></div><div className="horizon-values"><div><Sun size={14} /><span>Sun altitude</span><strong>{summary.peakSunAlt.toFixed(1)}° max</strong></div><div><Globe2 size={14} /><span>Earth altitude</span><strong>{summary.peakEarthAlt.toFixed(1)}° max</strong></div><div><Radio size={14} /><span>Visibility mode</span><strong>Reference sphere</strong></div></div></div></div>;
}

function App() {
  const [activeView, setActiveView] = useState<View>('overview');
  const [selectedSiteId, setSelectedSiteId] = useState('shackleton-ridge');
  const [compareIds, setCompareIds] = useState<string[]>(['shackleton-ridge', 'mons-mouton', 'malapert-a']);
  const [scenario, setScenario] = useState<Scenario>(DEFAULT_SCENARIO);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [astraOpen, setAstraOpen] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([{ role: 'astra', text: 'Mission systems nominal. I can interpret the current site, compare candidates, or explain any chart in AWILIX.' }]);
  const selectedSite = getSite(selectedSiteId);
  const selectedSummary = useMemo(() => getSummary(selectedSite, scenario), [selectedSite, scenario]);
  const comparisonSites = compareIds.map(getSite);

  const goTo = (view: View) => { setActiveView(view); if (window.innerWidth < 900) setSidebarOpen(false); };
  const openSite = (id: string) => { setSelectedSiteId(id); goTo('analysis'); };
  const toggleCompare = (id: string) => setCompareIds((current) => current.includes(id) ? current.filter((item) => item !== id) : current.length < 4 ? [...current, id] : current);
  const updateScenario = <K extends keyof Scenario>(key: K, value: Scenario[K]) => setScenario((current) => ({ ...current, [key]: value }));

  const askAstra = () => {
    const question = chatInput.trim();
    if (!question) return;
    const lower = question.toLowerCase();
    const compareNames = comparisonSites.map((site) => site.shortName).join(' and ');
    let answer = `For ${selectedSite.shortName}, the current ${scenario.windowHours}-hour reference-sphere estimate is ${selectedSummary.sunlight}% sunlight availability, ${selectedSummary.earth}% Earth visibility, and ${selectedSummary.power}% power opportunity. These are calculated from the AWILIX catalog record and the current scenario settings.`;
    if (lower.includes('best') || lower.includes('sunlight') || lower.includes('longest')) {
      const best = [...sites].sort((a, b) => getSummary(b, scenario).sunlight - getSummary(a, scenario).sunlight)[0];
      answer = `${best.shortName} is currently the strongest sunlight candidate at ${getSummary(best, scenario).sunlight}% in this window. Shackleton Ridge and Shackleton Rim benefit from their high polar relief, but terrain-crop limits mean this should be treated as a comparative estimate, not a landing guarantee.`;
    } else if (lower.includes('earth') || lower.includes('communication') || lower.includes('comm')) {
      answer = `Earth visibility describes whether the Earth is above the local reference horizon. ${selectedSite.shortName} currently returns ${selectedSummary.earth}% link visibility with an estimated peak Earth altitude of ${selectedSummary.peakEarthAlt.toFixed(1)}°. Antenna height changes the local geometric margin, but it cannot remove far-field terrain uncertainty.`;
    } else if (lower.includes('power') || lower.includes('panel')) {
      answer = `Power opportunity is not the same as sunlight percentage. AWILIX applies a panel-incidence factor to the Sun's altitude and your panel tilt/azimuth. At ${scenario.panelTilt}° tilt and ${scenario.panelAzimuth}° azimuth, ${selectedSite.shortName} returns ${selectedSummary.power}% average opportunity for this window.`;
    } else if (lower.includes('compare')) {
      answer = `The current comparison set is ${compareNames}. The values are normalized to the same ${scenario.windowHours}-hour window, so you can compare the trade-offs without treating the percentages as a mission-wide score.`;
    } else if (lower.includes('terrain') || lower.includes('slope')) {
      answer = `${selectedSite.shortName} has ${selectedSite.elevationReliefM.toLocaleString()} m of catalogued relief. The current readout uses a reference-sphere horizon; the original local terrain crop does not model far-field terrain, so local slope and horizon results should be treated as experimental where no terrain grid is loaded.`;
    } else if (lower.includes('scenario') || lower.includes('height') || lower.includes('change')) {
      answer = `Your custom scenario uses a ${scenario.observerHeight} m observer height, ${scenario.antennaHeight} m antenna height, ${scenario.panelTilt}° panel tilt, and a ${scenario.windowHours}-hour window. Increase antenna height to test link margin; panel tilt primarily changes power incidence, not whether the Sun is visible.`;
    }
    setMessages((current) => [...current, { role: 'user', text: question }, { role: 'astra', text: answer }]);
    setChatInput('');
  };

  return <div className="app-shell">
    <aside className={`sidebar ${sidebarOpen ? 'sidebar-open' : 'sidebar-collapsed'}`}>
      <div className="brand"><div className="brand-mark"><Moon size={21} /></div>{sidebarOpen && <div><strong>AWILIX</strong><span>LUNAR MISSION BROWSER</span></div>}</div>
      <div className="sidebar-status"><span className="status-dot" />{sidebarOpen && <><span>MISSION CONTROL</span><b>LIVE</b></>}</div>
      <nav className="main-nav" aria-label="Primary navigation">{navigation.map(({ id, label, icon: Icon }) => <button key={id} className={`nav-item ${activeView === id ? 'active' : ''}`} onClick={() => goTo(id)} title={!sidebarOpen ? label : undefined}><Icon size={17} /><span>{label}</span>{activeView === id && <i />}</button>)}</nav>
      {sidebarOpen && <div className="sidebar-bottom"><div className="data-health"><div className="health-head"><span>DATA HEALTH</span><ShieldCheck size={14} /></div><strong>98.4%</strong><div className="health-bar"><span /></div><small>Precomputed ephemeris ready</small></div><button className="sidebar-source" onClick={() => goTo('overview')}><Database size={14} /> <span>Sources & methodology</span><ExternalLink size={12} /></button></div>}
      <button className="sidebar-toggle" onClick={() => setSidebarOpen((value) => !value)} aria-label={sidebarOpen ? 'Collapse navigation' : 'Expand navigation'}>{sidebarOpen ? <PanelLeftClose size={16} /> : <PanelLeftOpen size={16} />}</button>
    </aside>
    <main className="main-area">
      <header className="topbar"><button className="mobile-menu" onClick={() => setSidebarOpen((value) => !value)}><Menu size={20} /></button><div className="breadcrumb"><span>AWILIX</span><ChevronDown size={13} /><b>{navigation.find((item) => item.id === activeView)?.label}</b></div><div className="topbar-actions"><div className="utc-clock"><Clock3 size={14} /><span>UTC</span><strong>14:32:07</strong></div><button className="icon-button" aria-label="Notifications"><Bell size={17} /><i /></button><div className="operator"><div className="operator-avatar">RC</div><div><strong>R. Calder</strong><span>Flight dynamics</span></div><ChevronDown size={14} /></div></div></header>
      <div className="page-content">{activeView === 'overview' && <Overview scenario={scenario} selectedSiteId={selectedSiteId} onSelect={setSelectedSiteId} onOpen={openSite} onNavigate={goTo} />}{activeView === 'globe' && <GlobeView scenario={scenario} selectedSiteId={selectedSiteId} onSelect={setSelectedSiteId} onOpen={openSite} />}{activeView === 'sites' && <SitesView scenario={scenario} selectedSiteId={selectedSiteId} compareIds={compareIds} onSelect={setSelectedSiteId} onToggleCompare={toggleCompare} onOpen={openSite} />}{activeView === 'analysis' && <AnalysisView site={selectedSite} scenario={scenario} onSelectSite={setSelectedSiteId} onNavigate={goTo} />}{activeView === 'compare' && <CompareView scenario={scenario} compareIds={compareIds} onToggleCompare={toggleCompare} onOpen={openSite} />}{activeView === 'scenario' && <ScenarioView site={selectedSite} scenario={scenario} onUpdate={updateScenario} onSelectSite={setSelectedSiteId} onNavigate={goTo} />}{activeView === 'astra' && <AstraPage selectedSite={selectedSite} summary={selectedSummary} scenario={scenario} onOpenChat={() => setAstraOpen(true)} />}</div>
      <footer className="page-footer"><span><span className="footer-pulse" />AWILIX SCIENCE CORE · LOCAL RUNTIME</span><span>NASA / JPL reference geometry · catalog snapshot 2025.03</span><span>Build 0.9.7</span></footer>
    </main>
    <button className={`astra-fab ${astraOpen ? 'fab-open' : ''}`} onClick={() => setAstraOpen((value) => !value)} aria-label="Open Astra assistant"><AstraAvatar compact /><span>ASTRA</span>{!astraOpen && <i className="astra-notice" />}</button>
    {astraOpen && <section className="astra-panel"><div className="astra-panel-head"><div className="astra-title"><AstraAvatar compact /><div><strong>ASTRA</strong><span>Mission support intelligence</span></div></div><div><button className="icon-button" onClick={() => setMessages([{ role: 'astra', text: 'Conversation cleared. Ask me about the selected site, scenario, or any chart.' }])} aria-label="Clear conversation"><Minus size={16} /></button><button className="icon-button" onClick={() => setAstraOpen(false)} aria-label="Close Astra"><X size={16} /></button></div></div><div className="astra-context"><span><span className="status-dot" />CONTEXT LINKED</span><b>{selectedSite.shortName}</b><span>·</span><span>{scenario.windowHours}H WINDOW</span></div><div className="chat-messages">{messages.map((message, index) => <div key={`${message.role}-${index}`} className={`chat-message ${message.role}`}><div className="chat-avatar">{message.role === 'astra' ? <Sparkles size={13} /> : 'RC'}</div><div><span className="chat-role">{message.role === 'astra' ? 'ASTRA' : 'YOU'}</span><p>{message.text}</p></div></div>)}</div><div className="astra-prompts"><button onClick={() => setChatInput('Which site has the best sunlight?')}>Best sunlight?</button><button onClick={() => setChatInput('Explain Earth visibility')}>Earth visibility</button><button onClick={() => setChatInput('Explain the current scenario')}>Scenario impact</button></div><div className="chat-input"><input value={chatInput} onChange={(event) => setChatInput(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') askAstra(); }} placeholder="Ask Astra about the mission..." /><button onClick={askAstra} aria-label="Send message"><Send size={16} /></button></div></section>}
  </div>;
}

function Overview({ scenario, selectedSiteId, onSelect, onOpen, onNavigate }: { scenario: Scenario; selectedSiteId: string; onSelect: (id: string) => void; onOpen: (id: string) => void; onNavigate: (view: View) => void }) {
  const summaries = sites.map((site) => ({ site, summary: getSummary(site, scenario) }));
  const averageSun = Math.round(summaries.reduce((sum, item) => sum + item.summary.sunlight, 0) / summaries.length);
  return <div className="view-stack"><div className="mission-hero"><div className="hero-copy"><div className="hero-kicker"><span className="pulse-line" />LUNAR SOUTH POLE · MISSION WINDOW 04</div><h1>Find the edge<br /><em>of the light.</em></h1><p>AWILIX turns time-dependent illumination, Earth visibility, and terrain context into a clear mission picture for six candidate sites.</p><div className="hero-actions"><button className="primary-button" onClick={() => onNavigate('globe')}>Explore lunar globe <ArrowUpRight size={16} /></button><button className="quiet-button" onClick={() => onOpen(selectedSiteId)}>Open site analysis <LineChart size={15} /></button></div><div className="hero-meta"><span><CalendarDays size={14} />{scenario.date}</span><span><Clock3 size={14} />{scenario.windowHours} hour window</span><span><Database size={14} />Reference data loaded</span></div></div><div className="hero-visual"><LunarGlobe selectedId={selectedSiteId} onSelect={onSelect} /><div className="hero-visual-label"><span>POLAR VIEW / 90°S</span><b>6</b><small>candidate sites</small></div></div></div><div className="metrics-grid"><MetricCard label="Solar availability" value={`${averageSun}`} unit="%" tone="amber" detail="six-site mean · current window" icon={Sun} /><MetricCard label="Earth visibility" value="84" unit="%" tone="cyan" detail="direct-to-Earth opportunity" icon={Globe2} /><MetricCard label="Power opportunity" value="79" unit="%" tone="blue" detail="panel incidence included" icon={Zap} /><MetricCard label="Ephemeris status" value="READY" tone="green" detail="precomputed reference set" icon={Activity} /></div><div className="overview-grid"><div className="panel site-overview-panel"><div className="panel-heading"><div><span className="eyebrow">CANDIDATE LANDING SITES</span><h2>South pole shortlist</h2></div><button className="text-button" onClick={() => onNavigate('sites')}>View all sites <ArrowUpRight size={14} /></button></div><div className="shortlist-list">{summaries.slice(0, 4).map(({ site, summary }, index) => <button className="shortlist-row" key={site.id} onClick={() => onOpen(site.id)}><span className="row-number" style={{ color: colors[index] }}>0{index + 1}</span><span className="row-name"><strong>{site.shortName}</strong><small>{formatCoordinate(site.lat, 'N', 'S')} · {formatCoordinate(site.lon, 'E', 'W')}</small></span><span className="row-bar"><i style={{ width: `${summary.sunlight}%`, background: colors[index] }} /></span><span className="row-value">{summary.sunlight}%</span><ArrowUpRight size={14} /></button>)}</div></div><div className="panel readiness-panel"><div className="panel-heading"><div><span className="eyebrow">MISSION READINESS</span><h2>Systems snapshot</h2></div><span className="panel-menu"><Settings2 size={16} /></span></div><div className="readiness-orb"><div className="readiness-ring"><strong>82</strong><span>READY</span></div><div className="orb-lines"><i /><i /><i /></div></div><div className="readiness-list"><div><span><i className="ready-dot" />Illumination model</span><b>Nominal</b></div><div><span><i className="ready-dot" />Earth geometry</span><b>Nominal</b></div><div><span><i className="ready-dot warn" />Terrain horizon</span><b>Experimental</b></div></div></div></div><div className="method-strip"><div><Info size={16} /><span><strong>Scientific transparency</strong> Results combine AWILIX catalog records with runtime reference-sphere calculations. Local terrain crops do not model far-field terrain.</span></div><button className="quiet-button" onClick={() => onNavigate('scenario')}>Review assumptions <ArrowUpRight size={14} /></button></div></div>;
}

function GlobeView({ scenario, selectedSiteId, onSelect, onOpen }: { scenario: Scenario; selectedSiteId: string; onSelect: (id: string) => void; onOpen: (id: string) => void }) {
  const site = getSite(selectedSiteId);
  const summary = getSummary(site, scenario);
  return <div className="view-stack"><SectionTitle eyebrow="LUNAR GLOBE / 01" title="The south pole, in context." description="A polar projection of the candidate set. Select a marker to update the mission readout." action={<div className="view-tools"><span><Move3d size={14} />Interactive view</span><button className="icon-button"><Compass size={16} /></button></div>} /><div className="globe-layout"><div className="panel large-globe-panel"><LunarGlobe selectedId={selectedSiteId} onSelect={onSelect} /><div className="globe-controls"><span>POLAR PROJECTION · LAT −84° TO −90°</span><div><button><Minus size={14} /></button><span>100%</span><button><PlusIcon /></button></div></div></div><div className="panel selected-readout"><div className="readout-label"><span className="eyebrow">SELECTED SITE</span><span className="site-status"><span />TRACKED</span></div><h2>{site.name}</h2><p>{site.targetRegion}</p><div className="coordinate-block"><div><span>LATITUDE</span><strong>{formatCoordinate(site.lat, 'N', 'S')}</strong></div><div><span>LONGITUDE</span><strong>{formatCoordinate(site.lon, 'E', 'W')}</strong></div></div><div className="readout-metrics"><div><Sun size={15} /><span>Sunlight</span><strong>{summary.sunlight}%</strong></div><div><Globe2 size={15} /><span>Earth link</span><strong>{summary.earth}%</strong></div><div><Radio size={15} /><span>Comms</span><strong>{summary.comm}%</strong></div></div><button className="primary-button full-button" onClick={() => onOpen(site.id)}>Open full analysis <ArrowUpRight size={16} /></button><div className="globe-legend"><span className="eyebrow">MARKER LEGEND</span>{sites.map((item, index) => <button key={item.id} onClick={() => onSelect(item.id)} className={item.id === selectedSiteId ? 'legend-active' : ''}><i style={{ background: colors[index] }} />{item.shortName}<b>{String(index + 1).padStart(2, '0')}</b></button>)}</div></div></div></div>;
}

function PlusIcon() { return <span className="plus-icon">+</span>; }

function SitesView({ scenario, selectedSiteId, compareIds, onSelect, onToggleCompare, onOpen }: { scenario: Scenario; selectedSiteId: string; compareIds: string[]; onSelect: (id: string) => void; onToggleCompare: (id: string) => void; onOpen: (id: string) => void }) {
  const [query, setQuery] = useState('');
  const visibleSites = sites.filter((site) => site.name.toLowerCase().includes(query.toLowerCase()));
  return <div className="view-stack"><SectionTitle eyebrow="CANDIDATE SITES / 02" title="Six places worth watching." description="The shortlist is drawn from the AWILIX south-pole catalog. Values update with the current mission window." action={<div className="site-toolbar"><div className="search-input"><Search size={15} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search sites" /></div><button className="quiet-button"><SlidersHorizontal size={14} /> Sort: sunlight</button></div>} /><div className="sites-note"><span><Info size={15} /><strong>{compareIds.length} sites</strong> selected for comparison</span><button className="text-button" onClick={() => onToggleCompare(selectedSiteId)}> {compareIds.includes(selectedSiteId) ? 'Remove selected' : 'Add selected'} <ArrowUpRight size={13} /></button></div><div className="site-grid">{visibleSites.map((site, index) => <SiteCard key={site.id} site={site} index={sites.findIndex((item) => item.id === site.id)} selected={compareIds.includes(site.id)} onSelect={() => onToggleCompare(site.id)} onOpen={() => { onSelect(site.id); onOpen(site.id); }} scenario={scenario} />)}</div></div>;
}

function AnalysisView({ site, scenario, onSelectSite, onNavigate }: { site: Site; scenario: Scenario; onSelectSite: (id: string) => void; onNavigate: (view: View) => void }) {
  const summary = getSummary(site, scenario);
  return <div className="view-stack"><div className="analysis-header"><div><span className="eyebrow">SITE ANALYSIS / 03</span><div className="analysis-title-row"><h1>{site.name}</h1><span className="site-status"><span />ACTIVE TARGET</span></div><p>{site.targetRegion} · {site.mission}</p></div><div className="site-switcher"><label>ACTIVE SITE</label><select value={site.id} onChange={(event) => onSelectSite(event.target.value)}>{sites.map((item) => <option key={item.id} value={item.id}>{item.shortName}</option>)}</select><ChevronDown size={14} /></div></div><div className="analysis-metrics"><MetricCard label="Solar visibility" value={`${summary.sunlight}`} unit="%" tone="amber" detail={`${summary.peakSunAlt.toFixed(1)}° peak altitude`} icon={Sun} /><MetricCard label="Earth visibility" value={`${summary.earth}`} unit="%" tone="cyan" detail={`${summary.peakEarthAlt.toFixed(1)}° peak altitude`} icon={Globe2} /><MetricCard label="Power opportunity" value={`${summary.power}`} unit="%" tone="blue" detail={`tilt ${scenario.panelTilt}° · az ${scenario.panelAzimuth}°`} icon={Zap} /><MetricCard label="Comm window" value={`${summary.comm}`} unit="%" tone="green" detail={`antenna ${scenario.antennaHeight} m`} icon={Radio} /></div><div className="analysis-grid"><ChartPanel site={site} scenario={scenario} /><AstroReadout site={site} scenario={scenario} /></div><div className="analysis-lower"><div className="panel detail-panel"><div className="panel-heading"><div><span className="eyebrow">SITE RECORD</span><h2>What the catalog tells us</h2></div><Database size={17} /></div><div className="detail-grid"><div><span>COORDINATES</span><strong>{formatCoordinate(site.lat, 'N', 'S')} / {formatCoordinate(site.lon, 'E', 'W')}</strong></div><div><span>RELIEF</span><strong>{site.elevationReliefM.toLocaleString()} m</strong></div><div><span>WATER-ICE POTENTIAL</span><strong>{site.waterIcePotential}</strong></div><div><span>CONTRACTOR / OWNER</span><strong>{site.contractor}</strong></div></div><div className="goal-list"><span className="eyebrow">KEY SCIENCE GOALS</span>{site.keyScienceGoals.map((goal) => <span key={goal}><Check size={13} />{goal}</span>)}</div></div><div className="panel limitation-panel"><div className="limitation-icon"><CircleHelp size={19} /></div><span className="eyebrow">LIMITATION NOTICE</span><h3>Far-field terrain is not modeled.</h3><p>The reference-sphere view is useful for comparison. Local terrain crops can alter a horizon, but they do not represent distant ridges or crater walls.</p><button className="text-button" onClick={() => onNavigate('scenario')}>Review scenario assumptions <ArrowUpRight size={14} /></button></div></div></div>;
}

function CompareView({ scenario, compareIds, onToggleCompare, onOpen }: { scenario: Scenario; compareIds: string[]; onToggleCompare: (id: string) => void; onOpen: (id: string) => void }) {
  const comparisonSites = compareIds.map(getSite);
  const rows: { label: string; key: 'sunlight' | 'earth' | 'power' | 'comm'; color: string }[] = [{ label: 'Solar visibility', key: 'sunlight', color: '#f0a970' }, { label: 'Earth visibility', key: 'earth', color: '#65d5d0' }, { label: 'Power opportunity', key: 'power', color: '#9aaeff' }, { label: 'Comm window', key: 'comm', color: '#9dde9b' }];
  return <div className="view-stack"><SectionTitle eyebrow="COMPARE SITES / 04" title="Trade-offs, made legible." description="Compare the current mission window without collapsing the science into a single unexplained score." action={<button className="primary-button" onClick={() => onToggleCompare(sites.find((site) => !compareIds.includes(site.id))?.id ?? sites[0].id)}><PlusIcon /> Add site</button>} /><div className="compare-chips">{sites.map((site, index) => <button key={site.id} className={compareIds.includes(site.id) ? 'chip-active' : ''} onClick={() => onToggleCompare(site.id)}><i style={{ background: colors[index] }} />{site.shortName}{compareIds.includes(site.id) && <X size={13} />}</button>)}</div>{comparisonSites.length === 0 ? <div className="empty-panel"><BarChart3 size={25} /><h3>Select at least one candidate</h3><p>Choose sites above to build a comparison.</p></div> : <><div className="panel comparison-chart"><div className="panel-heading"><div><span className="eyebrow">NORMALIZED COMPARISON · {scenario.windowHours}H</span><h2>Mission opportunity profile</h2></div><span className="chart-unit">0–100% normalized</span></div><div className="compare-bars">{rows.map((row) => <div className="compare-row" key={row.key}><div className="compare-row-label"><span>{row.label}</span><small>reference estimate</small></div><div className="compare-row-bars">{comparisonSites.map((site) => { const summary = getSummary(site, scenario); return <div className="compare-bar-wrap" key={site.id} title={`${site.shortName}: ${summary[row.key]}%`}><div className="compare-bar" style={{ height: `${summary[row.key]}%`, background: row.color }}><span>{summary[row.key]}</span></div><small>{site.shortName}</small></div>; })}</div></div>)}</div></div><div className="panel compare-table"><div className="panel-heading"><div><span className="eyebrow">SITE BREAKDOWN</span><h2>Keep the context attached</h2></div></div><div className="table-wrap"><table><thead><tr><th>Site</th><th>Sunlight</th><th>Earth link</th><th>Relief</th><th>Record</th></tr></thead><tbody>{comparisonSites.map((site) => { const summary = getSummary(site, scenario); return <tr key={site.id}><td><button className="table-site" onClick={() => onOpen(site.id)}><i style={{ background: colors[sites.findIndex((item) => item.id === site.id)] }} />{site.shortName}</button></td><td><MiniBars value={summary.sunlight} color="#f0a970" /></td><td><MiniBars value={summary.earth} color="#65d5d0" /></td><td>{site.elevationReliefM.toLocaleString()} m</td><td><button className="text-button" onClick={() => onOpen(site.id)}>Analyze <ArrowUpRight size={13} /></button></td></tr>; })}</tbody></table></div></div></>}</div>;
}

function ScenarioView({ site, scenario, onUpdate, onSelectSite, onNavigate }: { site: Site; scenario: Scenario; onUpdate: <K extends keyof Scenario>(key: K, value: Scenario[K]) => void; onSelectSite: (id: string) => void; onNavigate: (view: View) => void }) {
  const reference = getSummary(site, DEFAULT_SCENARIO);
  const custom = getSummary(site, scenario);
  return <div className="view-stack"><SectionTitle eyebrow="SCENARIO LAB / 05" title="Move the mission assumptions." description="Change the observing geometry, then see how the selected candidate responds." action={<div className="scenario-status"><span className="status-dot" />CUSTOM SCENARIO ACTIVE</div>} /><div className="scenario-grid"><div className="panel scenario-controls"><div className="panel-heading"><div><span className="eyebrow">SCENARIO INPUTS</span><h2>Mission assumptions</h2></div><Settings2 size={17} /></div><label className="control-label">ACTIVE SITE<select value={site.id} onChange={(event) => onSelectSite(event.target.value)}>{sites.map((item) => <option key={item.id} value={item.id}>{item.shortName}</option>)}</select></label><label className="control-label">MISSION DATE<div className="input-with-icon"><CalendarDays size={15} /><input type="date" value={scenario.date} onChange={(event) => onUpdate('date', event.target.value)} /></div></label><div className="control-label">TIME WINDOW<div className="segmented-control">{[24, 48, 168, 336].map((hours) => <button key={hours} className={scenario.windowHours === hours ? 'active' : ''} onClick={() => onUpdate('windowHours', hours)}>{hours < 168 ? `${hours}H` : `${hours / 24}D`}</button>)}</div></div><RangeControl label="Observer height" value={scenario.observerHeight} min={0} max={20} step={1} unit="m" onChange={(value) => onUpdate('observerHeight', value)} /><RangeControl label="Antenna height" value={scenario.antennaHeight} min={0} max={30} step={1} unit="m" onChange={(value) => onUpdate('antennaHeight', value)} /><RangeControl label="Panel tilt" value={scenario.panelTilt} min={0} max={90} step={1} unit="°" onChange={(value) => onUpdate('panelTilt', value)} /><RangeControl label="Panel azimuth" value={scenario.panelAzimuth} min={0} max={360} step={5} unit="°" onChange={(value) => onUpdate('panelAzimuth', value)} /><button className="quiet-button full-button" onClick={() => { onUpdate('date', DEFAULT_SCENARIO.date); onUpdate('windowHours', DEFAULT_SCENARIO.windowHours); onUpdate('observerHeight', DEFAULT_SCENARIO.observerHeight); onUpdate('antennaHeight', DEFAULT_SCENARIO.antennaHeight); onUpdate('panelTilt', DEFAULT_SCENARIO.panelTilt); onUpdate('panelAzimuth', DEFAULT_SCENARIO.panelAzimuth); }}>Reset to reference <Clock3 size={14} /></button></div><div className="scenario-results"><div className="panel scenario-result-hero"><div><span className="eyebrow">LIVE RESPONSE · {site.shortName}</span><h2>Custom scenario delta</h2><p>Compared with the AWILIX reference case, the current inputs produce these changes.</p></div><div className="delta-orbit"><div className="delta-ring"><strong>{custom.sunlight - reference.sunlight > 0 ? '+' : ''}{custom.sunlight - reference.sunlight}%</strong><span>SUNLIGHT</span></div><div className="delta-node"><Sun size={14} /></div></div></div><div className="delta-grid"><DeltaCard label="Solar visibility" reference={reference.sunlight} custom={custom.sunlight} icon={Sun} /><DeltaCard label="Earth visibility" reference={reference.earth} custom={custom.earth} icon={Globe2} /><DeltaCard label="Power opportunity" reference={reference.power} custom={custom.power} icon={Zap} /><DeltaCard label="Comm window" reference={reference.comm} custom={custom.comm} icon={Radio} /></div><ChartPanel site={site} scenario={scenario} /><div className="scenario-method"><Info size={15} /><span>Changing panel geometry affects power incidence. Observer and antenna heights affect local visibility margins. The model does not claim to predict far-field terrain blockage.</span><button className="text-button" onClick={() => onNavigate('analysis')}>Open full analysis <ArrowUpRight size={13} /></button></div></div></div></div>;
}

function RangeControl({ label, value, min, max, step, unit, onChange }: { label: string; value: number; min: number; max: number; step: number; unit: string; onChange: (value: number) => void }) {
  return <label className="range-control"><span>{label}<b>{value}{unit}</b></span><input type="range" min={min} max={max} step={step} value={value} onChange={(event) => onChange(Number(event.target.value))} /></label>;
}

function DeltaCard({ label, reference, custom, icon: Icon }: { label: string; reference: number; custom: number; icon: typeof Sun }) {
  const delta = custom - reference;
  return <div className="delta-card"><div className="delta-card-head"><span>{label}</span><Icon size={14} /></div><div className="delta-values"><strong>{custom}%</strong><span className={delta >= 0 ? 'delta-positive' : 'delta-negative'}>{delta >= 0 ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}{Math.abs(delta)} pts</span></div><div className="delta-track"><i style={{ width: `${reference}%` }} /><b style={{ width: `${custom}%` }} /></div><small>reference {reference}% · custom {custom}%</small></div>;
}

function AstraPage({ selectedSite, summary, scenario, onOpenChat }: { selectedSite: Site; summary: ReturnType<typeof getSummary>; scenario: Scenario; onOpenChat: () => void }) {
  return <div className="view-stack astra-page"><div className="astra-hero"><div><span className="eyebrow">ASTRA / 06</span><h1>Your mission<br /><em>co-pilot.</em></h1><p>Astra is context-aware by design. She reads the active AWILIX site, scenario, comparison set, and chart values so explanations stay anchored to the mission in front of you.</p><button className="primary-button" onClick={onOpenChat}>Open Astra channel <MessageCircle size={16} /></button></div><div className="astra-stage"><div className="astra-stage-grid" /><AstraAvatar /><div className="astra-stage-label"><span>ASTRA-01</span><b>CONTEXT AWARE</b></div></div></div><div className="astra-info-grid"><div className="panel astra-capabilities"><div className="panel-heading"><div><span className="eyebrow">CAPABILITIES</span><h2>Ask about what you can see.</h2></div><Sparkles size={17} /></div>{['Interpret solar visibility and power opportunity', 'Explain Earth visibility and communications windows', 'Compare the active candidate sites', 'Translate assumptions and limitations into plain language'].map((item) => <div className="capability" key={item}><span><Check size={13} /></span>{item}<ArrowUpRight size={14} /></div>)}</div><div className="panel astra-context-card"><div className="panel-heading"><div><span className="eyebrow">CURRENT CONTEXT</span><h2>What Astra can read</h2></div><Cpu size={17} /></div><div className="context-list"><div><span>Active site</span><strong>{selectedSite.shortName}</strong></div><div><span>Mission window</span><strong>{scenario.date} · {scenario.windowHours}h</strong></div><div><span>Sun visibility</span><strong>{summary.sunlight}% reference estimate</strong></div><div><span>Earth link</span><strong>{summary.earth}% reference estimate</strong></div></div><div className="context-note"><Info size={14} />Astra answers locally from the current session context. No made-up mission values.</div></div></div></div>;
}

export default App;
