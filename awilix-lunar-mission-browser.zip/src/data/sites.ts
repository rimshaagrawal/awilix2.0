export type Site = {
  id: string;
  name: string;
  shortName: string;
  lat: number;
  lon: number;
  mission: string;
  targetRegion: string;
  elevationReliefM: number;
  illuminationProfile: string;
  waterIcePotential: string;
  dteCommVisibility: string;
  contractor: string;
  keyScienceGoals: string[];
  sourceLabel: string;
  baseSunlight: number;
  baseEarth: number;
};

export const sites: Site[] = [
  {
    id: 'shackleton-rim',
    name: 'Shackleton Crater Rim',
    shortName: 'Shackleton Rim',
    lat: -89.9,
    lon: 0,
    mission: 'Candidate south-polar region; not a confirmed Artemis touchdown point',
    targetRegion: 'Lunar South Pole · Peak of Eternal Light',
    elevationReliefM: 4796,
    illuminationProfile: 'Peak illumination · approximately 86–92% annual sunlight on ridge points',
    waterIcePotential: 'Extremely high · permanently shadowed interior',
    dteCommVisibility: 'Direct-to-Earth link oscillates between +6° and −6° elevation',
    contractor: 'Illustrative region · no assigned mission',
    keyScienceGoals: ['Sample volatile water ice deposits', 'Long-duration solar power testing', 'Direct-to-Earth X-band relay'],
    sourceLabel: 'AWILIX catalog · south-pole candidate record',
    baseSunlight: 89,
    baseEarth: 78,
  },
  {
    id: 'malapert-a',
    name: 'Malapert A',
    shortName: 'Malapert A',
    lat: -86,
    lon: -2,
    mission: "IM-1 'Odysseus' regional marker",
    targetRegion: 'South Pole Uplands · near Malapert Mountain',
    elevationReliefM: 1270,
    illuminationProfile: 'Seasonal high illumination · approximately 70–80% during southern summer',
    waterIcePotential: 'Moderate to high in localized micro-cold traps',
    dteCommVisibility: 'High Earth elevation window with strong line-of-sight',
    contractor: 'Intuitive Machines · CLPS TO2-IM',
    keyScienceGoals: ['Radio astronomy precursor', 'Plume-surface interaction physics', 'Precision navigation demonstration'],
    sourceLabel: 'AWILIX catalog · mission-associated regional marker',
    baseSunlight: 76,
    baseEarth: 84,
  },
  {
    id: 'mons-mouton',
    name: 'Mons Mouton',
    shortName: 'Mons Mouton',
    lat: -84.5,
    lon: 29,
    mission: "IM-2 'Athena' / PRIME-1 regional marker",
    targetRegion: 'South Polar Plateau',
    elevationReliefM: 2110,
    illuminationProfile: 'Broad plateau with prolonged illumination windows · approximately 14 days',
    waterIcePotential: 'Subsurface volatiles possible within 1 m drill depth',
    dteCommVisibility: 'Unobstructed line-of-sight across the landing sequence',
    contractor: 'Intuitive Machines · PR-1 / PRIME-1',
    keyScienceGoals: ['TRIDENT ice drill', 'Volatile analysis', 'Lunar 4G/LTE communications test'],
    sourceLabel: 'AWILIX catalog · mission-associated regional marker',
    baseSunlight: 74,
    baseEarth: 91,
  },
  {
    id: 'nobile',
    name: 'Nobile Crater Rim',
    shortName: 'Nobile Rim',
    lat: -85.2,
    lon: 54,
    mission: 'Candidate south-polar comparison region; no confirmed mission landing point',
    targetRegion: 'South Polar Highlands',
    elevationReliefM: 427,
    illuminationProfile: 'Complex rim-valley lighting with ridge-cast shadows',
    waterIcePotential: 'Very high · extensive permanently shadowed regions',
    dteCommVisibility: 'Requires rover trajectory planning to retain line-of-sight',
    contractor: 'No mission assignment in this regional catalog',
    keyScienceGoals: ['Search for water ice and volatiles', 'Map volatile distribution', 'Subsurface neutron spectrometry'],
    sourceLabel: 'AWILIX catalog · south-pole candidate record',
    baseSunlight: 58,
    baseEarth: 73,
  },
  {
    id: 'shackleton-ridge',
    name: 'Shackleton Connecting Ridge',
    shortName: 'Shackleton Ridge',
    lat: -89.5,
    lon: 0,
    mission: 'Candidate south-polar region; future mission association unconfirmed',
    targetRegion: 'Connecting ridge between Shackleton and de Gerlache',
    elevationReliefM: 4796,
    illuminationProfile: 'Ultra-prolonged sunlight · one of the highest sunlit points on the Moon',
    waterIcePotential: 'High access to adjacent permanently shadowed regions',
    dteCommVisibility: 'Earth hovers continuously 1° to 8° above the horizon',
    contractor: 'Illustrative region · no assigned mission',
    keyScienceGoals: ['Base Camp power hub', 'Cryogenic propellant infrastructure', 'Long-range robotic traverses'],
    sourceLabel: 'AWILIX catalog · south-pole candidate record',
    baseSunlight: 93,
    baseEarth: 96,
  },
  {
    id: 'south-pole',
    name: 'Geographic South Pole',
    shortName: 'Geographic Pole',
    lat: -90,
    lon: 0,
    mission: 'Scientific reference and calibration datum',
    targetRegion: 'Selenographic 90°S axis',
    elevationReliefM: 4606,
    illuminationProfile: 'Sun never rises more than 1.54° above or below the horizon year-round',
    waterIcePotential: 'Variable depending on local rim topography',
    dteCommVisibility: 'Earth stays within ±6.7° of the horizon due to libration',
    contractor: 'International Astronomical Union / NASA geodesy',
    keyScienceGoals: ['Lunar coordinate frame calibration', 'Fundamental gravitational physics', 'Long-baseline interferometry'],
    sourceLabel: 'AWILIX catalog · scientific reference datum',
    baseSunlight: 64,
    baseEarth: 68,
  },
];

export const getSite = (id: string): Site => sites.find((site) => site.id === id) ?? sites[0];
